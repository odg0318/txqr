package com.txqr;

import java.util.Arrays;

/**
 * A block represents a contiguous range of data being encoded or decoded,
 * or a block of coded data.
 * Port of google/gofountain's block type.
 */
public class Block {

    byte[] data;
    int padding;

    public Block() {
        this.data = new byte[0];
        this.padding = 0;
    }

    public Block(byte[] data) {
        this.data = data != null ? data : new byte[0];
        this.padding = 0;
    }

    public Block(byte[] data, int padding) {
        this.data = data != null ? data : new byte[0];
        this.padding = padding;
    }

    public int length() {
        return data.length + padding;
    }

    public boolean empty() {
        return length() == 0;
    }

    /**
     * XOR this block with another block.
     * Padding bytes count as 0 (XOR identity).
     * This block will be expanded if necessary.
     */
    public void xor(Block a) {
        if (data.length < a.data.length) {
            int inc = a.data.length - data.length;
            byte[] newData = new byte[a.data.length];
            System.arraycopy(data, 0, newData, 0, data.length);
            data = newData;
            if (padding > inc) {
                padding -= inc;
            } else {
                padding = 0;
            }
        }

        for (int i = 0; i < a.data.length; i++) {
            data[i] ^= a.data[i];
        }
    }

    public Block copy() {
        byte[] dataCopy = Arrays.copyOf(data, data.length);
        return new Block(dataCopy, padding);
    }
}
