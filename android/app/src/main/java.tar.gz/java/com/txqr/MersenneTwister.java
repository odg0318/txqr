package com.txqr;

/**
 * MT19937 (32-bit) Mersenne Twister PRNG.
 * Port of google/gofountain's MersenneTwister to match its exact output.
 *
 * Also implements Go's math/rand.Rand methods (Int63, Int31, Int31n, Intn,
 * Float64) on top of the MT Source so that PickIndices produces identical
 * index sequences to the Go implementation.
 */
public class MersenneTwister {

    private static final int N = 624;
    private static final int M = 397;
    private static final long MAX_UINT32 = 0xFFFFFFFFL;

    private final long[] mt = new long[N];
    private int index;
    private boolean initialized;

    public MersenneTwister(long seed) {
        seed(seed);
    }

    // ---- gofountain MersenneTwister.Seed ----

    /**
     * Matches gofountain: seed = ((seed >> 32) ^ seed) & MaxUint32
     */
    public void seed(long seed) {
        long s = ((seed >> 32) ^ seed) & MAX_UINT32;
        initialize(s);
    }

    private void initialize(long seed) {
        index = 0;
        mt[0] = seed & MAX_UINT32;
        for (int i = 1; i < N; i++) {
            mt[i] = (1812433253L * (mt[i - 1] ^ (mt[i - 1] >> 30)) + i) & MAX_UINT32;
        }
        initialized = true;
    }

    private void generateUntempered() {
        long[] mag01 = {0x0L, 0x9908b0dfL};
        for (int i = 0; i < N; i++) {
            long y = (mt[i] & 0x80000000L) | (mt[(i + 1) % N] & 0x7fffffffL);
            mt[i] = (mt[(i + M) % N] ^ (y >> 1)) ^ mag01[(int) (y & 0x01)];
        }
    }

    // ---- gofountain MersenneTwister.Uint32 (raw Source method) ----

    /**
     * Returns the next 32-bit unsigned value (as a long to avoid sign issues).
     */
    public long nextUint32() {
        if (!initialized) {
            initialize(4357);
        }
        if (index == 0) {
            generateUntempered();
        }

        long y = mt[index];
        index++;
        if (index >= N) {
            index = 0;
        }
        y ^= y >> 11;
        y ^= (y << 7) & 0x9d2c5680L;
        y ^= (y << 15) & 0xefc60000L;
        y ^= y >> 18;

        return y & MAX_UINT32;
    }

    // ---- gofountain MersenneTwister.Int63  (Source interface) ----

    /**
     * Matches gofountain Int63: (a << 31) ^ b
     * This is the Source.Int63() that Go's rand.Rand calls internally.
     */
    public long nextInt63() {
        long a = nextUint32();
        long b = nextUint32();
        return (a << 31) ^ b;
    }

    // ---- Go rand.Rand methods built on top of Source.Int63 ----

    /**
     * Go rand.Uint32(): uint32(Int63() >> 31)
     */
    public long goUint32() {
        return nextInt63() >>> 31;
    }

    /**
     * Go rand.Int31(): int32(Int63() >> 32)
     */
    public int goInt31() {
        return (int) (nextInt63() >> 32);
    }

    /**
     * Go rand.Int31n(n): rejection sampling.
     * Panics if n <= 0.
     */
    public int goInt31n(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("invalid argument to Int31n");
        }
        if ((n & (n - 1)) == 0) { // power of two
            return goInt31() & (n - 1);
        }
        int max = 0x7fffffff - (0x7fffffff % n); // int32 max - (max % n)
        int v = goInt31();
        while (v > max) {
            v = goInt31();
        }
        return v % n;
    }

    /**
     * Go rand.Int63n(n): rejection sampling.
     */
    public long goInt63n(long n) {
        if (n <= 0) {
            throw new IllegalArgumentException("invalid argument to Int63n");
        }
        if ((n & (n - 1)) == 0) { // power of two
            return nextInt63() & (n - 1);
        }
        // max = (1<<63 - 1) - (1<<63)%uint64(n)
        // In Java: Long.MAX_VALUE - Long.remainderUnsigned(Long.MIN_VALUE, n)
        // Since (1<<63) as unsigned = Long.MIN_VALUE in two's complement
        long max = Long.MAX_VALUE - Long.remainderUnsigned(Long.MIN_VALUE, n);
        long v = nextInt63();
        while (v > max) {
            v = nextInt63();
        }
        return v % n;
    }

    /**
     * Go rand.Intn(n): delegates to Int31n for n <= 2^31-1, else Int63n.
     */
    public int nextGoIntn(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("invalid argument to Intn");
        }
        if (n <= (1 << 31) - 1) {
            return (int) goInt31n(n);
        }
        return (int) goInt63n(n);
    }

    /**
     * Go rand.Float64(): float64(Int63()) / (1 << 63)
     * Retries if result == 1.0 (extremely rare).
     */
    public double nextGoFloat64() {
        double f;
        do {
            f = (double) nextInt63() / (double) (1L << 63);
        } while (f == 1.0);
        return f;
    }
}
