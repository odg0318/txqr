package com.txqr;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

/**
 * TXQR protocol decoder for Android.
 * Port of github.com/divan/txqr's Decoder + mobile/Decoder.
 *
 * Protocol frame format: "blockCode/chunkLen/total|payload"
 *
 * Usage:
 *   TxqrDecoder decoder = new TxqrDecoder();
 *   while (!decoder.isCompleted()) {
 *       String qrData = ...; // scanned QR code content
 *       decoder.decode(qrData);
 *   }
 *   String result = decoder.getData();
 */
public class TxqrDecoder {

    private int chunkLen;
    private int total;
    private boolean completed;

    private LubyCodec codec;
    private FountainDecoder fd;
    private final Set<String> cache;

    // Progress tracking (matches mobile/decode.go)
    private int progress;
    private long startTimeMs;
    private long lastChunkTimeMs;
    private long readIntervalMs;

    public TxqrDecoder() {
        this.cache = new HashSet<>();
        this.startTimeMs = 0;
        this.lastChunkTimeMs = 0;
    }

    /**
     * Create a decoder for a known data size and chunk length.
     */
    public TxqrDecoder(int size, int chunkLen) {
        this();
        this.total = size;
        this.chunkLen = chunkLen;
        initCodec(size, chunkLen);
    }

    private void initCodec(int size, int chunkLen) {
        int numChunks = LubyCodec.numberOfChunks(size, chunkLen);
        double[] cdf = LubyCodec.solitonDistribution(numChunks);
        MersenneTwister rng = new MersenneTwister(200);
        this.codec = new LubyCodec(numChunks, rng, cdf);
        this.fd = codec.newDecoder(size);
    }

    /**
     * Validate a chunk string.
     * Returns null if valid, or an error message if invalid.
     */
    public String validate(String chunk) {
        if (chunk == null || chunk.length() < 4) {
            return "invalid frame: \"" + chunk + "\"";
        }
        int idx = chunk.indexOf('|');
        if (idx == -1) {
            return "invalid frame: \"" + chunk + "\"";
        }
        return null;
    }

    /**
     * Decode a single QR frame.
     * Returns null on success, or an error message on failure.
     */
    public String decode(String chunk) {
        // Ignore if already completed (matches mobile behavior)
        if (completed) {
            return null;
        }

        // Validate
        String err = validate(chunk);
        if (err != null) {
            return err;
        }

        int idx = chunk.indexOf('|');
        if (idx == -1) {
            return "invalid frame: \"" + chunk + "\"";
        }

        String header = chunk.substring(0, idx);

        // Skip duplicate chunks
        if (isCached(header)) {
            return null;
        }

        // Mark timing
        long now = System.currentTimeMillis();
        if (startTimeMs == 0) {
            startTimeMs = now;
        }
        if (lastChunkTimeMs != 0) {
            readIntervalMs = now - lastChunkTimeMs;
        }
        lastChunkTimeMs = now;

        // Parse header: "blockCode/chunkLen/total"
        String[] parts = header.split("/");
        if (parts.length != 3) {
            return "invalid header: " + header;
        }

        long blockCode;
        int parsedChunkLen;
        int parsedTotal;
        try {
            blockCode = Long.parseLong(parts[0]);
            parsedChunkLen = Integer.parseInt(parts[1]);
            parsedTotal = Integer.parseInt(parts[2]);
        } catch (NumberFormatException e) {
            return "invalid header: " + header + " (" + e.getMessage() + ")";
        }

        byte[] payload = chunk.substring(idx + 1).getBytes(StandardCharsets.ISO_8859_1);

        // Initialize codec on first frame if not already set
        if (fd == null) {
            this.total = parsedTotal;
            this.chunkLen = parsedChunkLen;
            initCodec(parsedTotal, parsedChunkLen);
        }

        completed = fd.addBlock(blockCode, payload);

        return null;
    }

    /**
     * Returns true if decoding is complete.
     */
    public boolean isCompleted() {
        return completed;
    }

    /**
     * Returns the decoded data as a String.
     */
    public String getData() {
        byte[] bytes = getDataBytes();
        return new String(bytes, StandardCharsets.ISO_8859_1);
    }

    /**
     * Returns the decoded data as a byte array.
     */
    public byte[] getDataBytes() {
        if (fd == null || !completed) {
            return new byte[0];
        }
        return fd.decode();
    }

    /**
     * Returns the total data size in bytes.
     */
    public int getTotal() {
        return total;
    }

    /**
     * Returns progress percentage (0-100).
     */
    public int getProgress() {
        return progress;
    }

    /**
     * Returns the read interval between last two chunks in milliseconds.
     */
    public long getReadIntervalMs() {
        return readIntervalMs;
    }

    /**
     * Returns total scan time in milliseconds.
     */
    public long getTotalTimeMs() {
        if (startTimeMs == 0) {
            return 0;
        }
        return System.currentTimeMillis() - startTimeMs;
    }

    /**
     * Reset the decoder for a new scan session.
     */
    public void reset() {
        fd = null;
        codec = null;
        completed = false;
        chunkLen = 0;
        total = 0;
        cache.clear();
        progress = 0;
        startTimeMs = 0;
        lastChunkTimeMs = 0;
        readIntervalMs = 0;
    }

    private boolean isCached(String header) {
        if (cache.contains(header)) {
            return true;
        }
        cache.add(header);
        return false;
    }
}
