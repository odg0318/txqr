package com.txqr;

/**
 * Luby Transform fountain code decoder.
 * Port of google/gofountain's lubyDecoder.
 *
 * Receives LT-encoded blocks, adds them to a sparse equation matrix,
 * and reconstructs the original message once enough blocks are collected.
 */
public class FountainDecoder {

    private final LubyCodec codec;
    private final int messageLength;
    private final SparseMatrix matrix;

    public FountainDecoder(LubyCodec codec, int messageLength) {
        this.codec = codec;
        this.messageLength = messageLength;
        this.matrix = new SparseMatrix(codec.getSourceBlocks());
    }

    /**
     * Add a single LT block to the decoder.
     * Returns true if the message can be fully decoded.
     */
    public boolean addBlock(long blockCode, byte[] data) {
        int[] indices = codec.pickIndices(blockCode);
        matrix.addEquation(indices, new Block(data));
        return matrix.determined();
    }

    /**
     * Add multiple LT blocks at once.
     * Returns true if the message can be fully decoded.
     */
    public boolean addBlocks(long[] blockCodes, byte[][] dataArrays) {
        for (int i = 0; i < blockCodes.length; i++) {
            int[] indices = codec.pickIndices(blockCodes[i]);
            matrix.addEquation(indices, new Block(dataArrays[i]));
        }
        return matrix.determined();
    }

    /**
     * Check if enough blocks have been received to fully decode.
     */
    public boolean isDetermined() {
        return matrix.determined();
    }

    /**
     * Decode and return the original message bytes.
     * Returns null if insufficient data.
     */
    public byte[] decode() {
        if (!matrix.determined()) {
            return null;
        }

        matrix.reduce();

        int[] p = LubyCodec.partition(messageLength, codec.getSourceBlocks());
        int lenLong = p[0];
        int lenShort = p[1];
        int numLong = p[2];
        int numShort = p[3];

        return matrix.reconstruct(messageLength, lenLong, lenShort, numLong, numShort);
    }
}
