package com.txqr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Sparse equation matrix used for fountain code decoding.
 * Port of google/gofountain's sparseMatrix.
 *
 * Each row represents an XOR equation:
 *   coeff[i] lists the indices of source blocks XORed together,
 *   v[i] holds the resulting block value.
 *
 * Invariant maintained during addEquation: coeff[i][0] == i or coeff[i] is empty.
 */
public class SparseMatrix {

    int[][] coeff;
    Block[] v;

    public SparseMatrix(int size) {
        coeff = new int[size][];
        v = new Block[size];
        for (int i = 0; i < size; i++) {
            coeff[i] = null; // null means empty row
            v[i] = new Block();
        }
    }

    /**
     * XOR the candidate equation (indices, b) with matrix row s.
     * Returns the symmetric difference of coefficients and XORed block.
     */
    private XorResult xorRow(int s, int[] indices, Block b) {
        b.xor(v[s]);

        int[] coeffs = coeff[s];
        List<Integer> newIndices = new ArrayList<>();
        int i = 0, j = 0;
        while (i < coeffs.length && j < indices.length) {
            if (coeffs[i] == indices[j]) {
                i++;
                j++;
            } else if (coeffs[i] < indices[j]) {
                newIndices.add(coeffs[i]);
                i++;
            } else {
                newIndices.add(indices[j]);
                j++;
            }
        }
        while (i < coeffs.length) {
            newIndices.add(coeffs[i]);
            i++;
        }
        while (j < indices.length) {
            newIndices.add(indices[j]);
            j++;
        }

        int[] result = new int[newIndices.size()];
        for (int k = 0; k < newIndices.size(); k++) {
            result[k] = newIndices.get(k);
        }
        return new XorResult(result, b);
    }

    /**
     * Add an XOR equation to the decode matrix.
     * Maintains triangular form: coeff[i][0] == i or row is empty.
     */
    public void addEquation(int[] components, Block b) {
        while (components.length > 0 && coeff[components[0]] != null && coeff[components[0]].length > 0) {
            int s = components[0];
            if (components.length >= coeff[s].length) {
                XorResult result = xorRow(s, components, b);
                components = result.indices;
                b = result.block;
            } else {
                // Swap the existing row for the new one
                int[] tempCoeff = coeff[s];
                coeff[s] = components;
                components = tempCoeff;

                Block tempBlock = v[s];
                v[s] = b;
                b = tempBlock;
            }
        }

        if (components.length > 0) {
            coeff[components[0]] = components;
            v[components[0]] = b;
        }
    }

    /**
     * Check if the decode matrix is fully determined.
     * True when all rows have non-empty coefficient slices.
     */
    public boolean determined() {
        for (int[] r : coeff) {
            if (r == null || r.length == 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Gaussian Elimination over the whole matrix.
     * Assumes the matrix is triangular.
     */
    public void reduce() {
        for (int i = coeff.length - 1; i >= 0; i--) {
            for (int j = 0; j < i; j++) {
                int[] ci = coeff[i];
                int[] cj = coeff[j];
                if (ci == null || cj == null) continue;
                for (int k = 1; k < cj.length; k++) {
                    if (cj[k] == ci[0]) {
                        v[j].xor(v[i]);
                        break;
                    }
                }
            }
            // Keep only the leading coefficient
            if (coeff[i] != null && coeff[i].length > 0) {
                coeff[i] = new int[]{coeff[i][0]};
            }
        }
    }

    /**
     * Reconstruct the original message from the fully reduced matrix.
     */
    public byte[] reconstruct(int totalLength, int lenLong, int lenShort, int numLong, int numShort) {
        byte[] out = new byte[totalLength];
        int pos = 0;
        for (int i = 0; i < numLong; i++) {
            int copyLen = Math.min(lenLong, v[i].data.length);
            System.arraycopy(v[i].data, 0, out, pos, copyLen);
            pos += lenLong;
        }
        for (int i = numLong; i < numLong + numShort; i++) {
            int copyLen = Math.min(lenShort, v[i].data.length);
            if (copyLen > 0) {
                System.arraycopy(v[i].data, 0, out, pos, copyLen);
            }
            pos += lenShort;
        }

        // Trim to totalLength in case pos exceeds
        if (pos > totalLength) {
            return Arrays.copyOf(out, totalLength);
        }
        return out;
    }

    private static class XorResult {
        int[] indices;
        Block block;

        XorResult(int[] indices, Block block) {
            this.indices = indices;
            this.block = block;
        }
    }
}
