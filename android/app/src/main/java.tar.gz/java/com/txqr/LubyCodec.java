package com.txqr;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Luby Transform codec for fountain codes.
 * Port of google/gofountain's lubyCodec.
 *
 * Handles block partitioning, degree distribution sampling,
 * and index selection for LT encoding/decoding.
 */
public class LubyCodec {

    private final int sourceBlocks;
    private final MersenneTwister random;
    private final double[] degreeCDF;

    public LubyCodec(int sourceBlocks, MersenneTwister random, double[] degreeCDF) {
        this.sourceBlocks = sourceBlocks;
        this.random = random;
        this.degreeCDF = degreeCDF;
    }

    public int getSourceBlocks() {
        return sourceBlocks;
    }

    /**
     * Pick the source block indices for a given code block ID.
     * Seeds the PRNG with the block code, picks a degree from the CDF,
     * then uniformly samples that many unique indices from [0, sourceBlocks).
     */
    public int[] pickIndices(long codeBlockIndex) {
        random.seed(codeBlockIndex);
        int d = pickDegree(random, degreeCDF);
        return sampleUniform(random, d, sourceBlocks);
    }

    /**
     * Create a new LubyDecoder for the given message length.
     */
    public FountainDecoder newDecoder(int messageLength) {
        return new FountainDecoder(this, messageLength);
    }

    // --- Static utility methods ---

    /**
     * Soliton distribution CDF.
     * Matches gofountain/txqr: cdf[1] = 1/n, cdf[i] = cdf[i-1] + 1/(i*(i-1))
     */
    public static double[] solitonDistribution(int n) {
        double[] cdf = new double[n + 1];
        cdf[1] = 1.0 / n;
        for (int i = 2; i <= n; i++) {
            cdf[i] = cdf[i - 1] + (1.0 / ((double) i * (i - 1)));
        }
        return cdf;
    }

    /**
     * Pick degree: smallest index i such that cdf[i] >= r.
     * Matches gofountain's pickDegree using binary search.
     */
    static int pickDegree(MersenneTwister random, double[] cdf) {
        double r = random.nextGoFloat64();
        // Binary search: find smallest d such that cdf[d] >= r
        int d = Arrays.binarySearch(cdf, r);
        if (d < 0) {
            // insertion point
            d = -(d + 1);
        }
        // Ensure we have cdf[d] >= r
        if (d < cdf.length && cdf[d] >= r) {
            return d;
        }
        // If cdf[d] > r already, return d
        if (d > 0 && d < cdf.length && cdf[d] > r) {
            return d;
        }
        if (d < cdf.length - 1) {
            return d + 1;
        }
        return cdf.length - 1;
    }

    /**
     * Sample num unique indices from [0, max) uniformly.
     * Returns sorted array. Matches gofountain's sampleUniform.
     */
    static int[] sampleUniform(MersenneTwister random, int num, int max) {
        if (num >= max) {
            int[] picks = new int[max];
            for (int i = 0; i < max; i++) {
                picks[i] = i;
            }
            return picks;
        }

        int[] picks = new int[num];
        Set<Integer> seen = new HashSet<>();
        for (int i = 0; i < num; i++) {
            int p = random.nextGoIntn(max);
            while (seen.contains(p)) {
                p = random.nextGoIntn(max);
            }
            picks[i] = p;
            seen.add(p);
        }
        Arrays.sort(picks);
        return picks;
    }

    /**
     * Partition function from RFC 5053 S.5.3.1.2.
     * Partitions size i into j semi-equal pieces.
     * Returns [lenLong, lenShort, numLong, numShort].
     */
    public static int[] partition(int i, int j) {
        int il = (int) Math.ceil((double) i / j);
        int is = (int) Math.floor((double) i / j);
        int jl = i - (is * j);
        int js = j - jl;

        if (jl == 0) il = 0;
        if (js == 0) is = 0;

        return new int[]{il, is, jl, js};
    }

    /**
     * Number of chunks needed to hold the given length with chunkLen-sized chunks.
     */
    public static int numberOfChunks(int length, int chunkLen) {
        int n = length / chunkLen;
        if (length % chunkLen > 0) {
            n++;
        }
        return n;
    }
}
